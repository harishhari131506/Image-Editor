import React, { FC,ReactNode } from 'react';
import cn from 'classnames';
import './VerticalButton.scss';

interface Props {
	className?: string;
	children: ReactNode;
}

export const VerticalButtons: FC<Props> = ({ children, className, ...props }) => {
	return <div className={cn('vertical-buttons', className)}>{children}</div>;
};