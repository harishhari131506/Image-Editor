import { useState, useRef } from "react";
import cn from "classnames";
import {
  Cropper,
  CropperRef,
  CropperPreview,
  CropperPreviewRef,
} from "react-advanced-cropper";
import { AdjustablePreviewBackground } from "./components/AdjustablePreviewBackground";
import { Navigation } from "./components/Navigation";
import { Slider } from "./components/Slider";
import { AdjustableCropperBackground } from "./components/AdjustableCropperBackground";
import { Button } from "./components/Button";
import { ResetIcon } from "./icons/icons/ResetIcon";
import "./ImagEditor.scss";
import "react-advanced-cropper/dist/style.css";


//   --------------------------------------------------

import { SquareButton } from './components/Vertical_components/SquareButton';
import { VerticalButtons } from './components/Vertical_components/VerticalButtons';
import { RotateLeftIcon } from './components/Vertical_components/icons/RotateLeftIcon';
import { RotateRightIcon } from './components/Vertical_components/icons/RotateRightIcon';
import { FlipHorizontalIcon } from './components/Vertical_components/icons/FlipHorizontalIcon';
import { FlipVerticalIcon } from './components/Vertical_components/icons/FlipVerticalIcon';

//  --------------------------------------------------


export const App = () => {
  const cropperRef = useRef<CropperRef>(null);
  const previewRef = useRef<CropperPreviewRef>(null);

  const [src, setSrc] = useState(
    "https://images.pexels.com/photos/360912/pexels-photo-360912.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
  );
  
  const [mode, setMode] = useState("");

  const [adjustments, setAdjustments] = useState({
    brightness: 0,
    hue: 0,
    saturation: 0,
    contrast: 0,
  });

  const onChangeValue = (value: number) => {
    if (mode in adjustments) {
      setAdjustments((previousValue) => ({
        ...previousValue,
        [mode]: value,
      }));
    }
  };

  const onReset = () => {
    setMode("");
    setAdjustments({
      brightness: 0,
      hue: 0,
      saturation: 0,
      contrast: 0,
    });
  };

  const onUpload = (blob: string) => {
    onReset();
    setMode("");
    setSrc(blob);
  };

  const onDownload = () => {
    if (cropperRef.current) {
      const newTab = window.open();
      if (newTab) {
        newTab.document.body.innerHTML = `<img src="${cropperRef.current
          .getCanvas()
          ?.toDataURL()}"/>`;
      }
    }
  };

  const onUpdate = () => {
    previewRef.current?.refresh();
  };

  const changed = Object.values(adjustments).some((el) => Math.floor(el * 100));

  const cropperEnabled = mode === "crop";

//   --------------------------------------------------

const flip = (horizontal: boolean, vertical: boolean) => () => {
	cropperRef.current?.flipImage(horizontal, vertical);
};

const rotate = (angle: number) => () => {
	cropperRef.current?.rotateImage(angle);
};

//   --------------------------------------------------

  return (
    <div className={"image-editor"}>
      <div className="image-editor__cropper">
	  <CropperPreview
          className={"image-editor__preview"}
          ref={previewRef}
          cropper={cropperRef}
          backgroundComponent={AdjustablePreviewBackground}
          backgroundProps={adjustments}
        />
      <Cropper
          src={src}
          ref={cropperRef}
          stencilProps={{
            movable: cropperEnabled,
            resizable: cropperEnabled,
            lines: cropperEnabled,
            handlers: cropperEnabled,
            overlayClassName: cn(
              "image-editor__cropper-overlay",
              !cropperEnabled && "image-editor__cropper-overlay--faded"
            ),
          }}
          backgroundWrapperProps={{
            scaleImage: cropperEnabled,
            moveImage: cropperEnabled,
          }}
          backgroundComponent={AdjustableCropperBackground}
          backgroundProps={adjustments}
          onUpdate={onUpdate}
		  
        />
		 
{/* ---------------------------------------------------------------------------------------------------------------------- */}
			<VerticalButtons>
				<SquareButton title="Flip Horizontal" onClick={flip(true, false)}>
					<FlipHorizontalIcon />
				</SquareButton>
				<SquareButton title="Flip Vertical" onClick={flip(false, true)}>
					<FlipVerticalIcon />
				</SquareButton>
				<SquareButton title="Rotate Clockwise" onClick={rotate(90)}>
					<RotateRightIcon />
				</SquareButton>
				<SquareButton title="Rotate Counter-Clockwise" onClick={rotate(-90)}>
					<RotateLeftIcon />
				</SquareButton>
			</VerticalButtons>


{/* ---------------------------------------------------------------------------------------------------------------------- */}
        {mode !== "crop" && (
          <Slider
            className="image-editor__slider"
            value={adjustments[mode as keyof typeof adjustments]}
            onChange={onChangeValue}
          />
        )}
      
        <Button
          className={cn(
            "image-editor__reset-button",
            !changed && "image-editor__reset-button--hidden"
          )}
          onClick={onReset}
        >
          <ResetIcon />
        </Button>
      </div>
      <Navigation
        mode={mode}
        onChange={setMode}
        onUpload={onUpload}
        onDownload={onDownload}
      />
    </div>
  );
};

export default App;
